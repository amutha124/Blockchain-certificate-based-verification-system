let blockchain = [];
let pendingCertificates = [];

function sha256(str) {
  return crypto.subtle.digest("SHA-256", new TextEncoder().encode(str)).then(buf => {
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
  });
}

function createGenesisBlock() {
  return {
    index: 0,
    timestamp: new Date().toISOString(),
    certificates: [],
    previousHash: "0",
    hash: "0"
  };
}

async function mineBlock() {
  if (pendingCertificates.length === 0) {
    alert("No certificates to mine.");
    return;
  }

  const previousBlock = blockchain[blockchain.length - 1];
  const blockData = {
    index: blockchain.length,
    timestamp: new Date().toISOString(),
    certificates: [...pendingCertificates],
    previousHash: previousBlock.hash
  };

  blockData.hash = await sha256(JSON.stringify(blockData));
  blockchain.push(blockData);
  pendingCertificates = [];
  renderBlockchain();
  alert("Block mined!");
}

function addCertificate() {
  const studentName = document.getElementById("studentName").value;
  const course = document.getElementById("course").value;
  const date = document.getElementById("date").value;

  if (studentName && course && date) {
    pendingCertificates.push({ studentName, course, date });
    alert("Certificate added to pending block.");
  } else {
    alert("Please fill all fields.");
  }
}

function verifyCertificate() {
  const name = document.getElementById("vName").value;
  const course = document.getElementById("vCourse").value;
  const date = document.getElementById("vDate").value;
  const cert = { studentName: name, course, date };

  for (let block of blockchain) {
    if (block.certificates.some(c =>
      c.studentName === cert.studentName &&
      c.course === cert.course &&
      c.date === cert.date)) {
      document.getElementById("verifyResult").innerText = `✅ Certificate is valid in block ${block.index}`;
      return;
    }
  }
  document.getElementById("verifyResult").innerText = "❌ Certificate not found.";
}

function renderBlockchain() {
  const container = document.getElementById("blockchain");
  container.innerHTML = "";
  blockchain.forEach(block => {
    const div = document.createElement("div");
    div.className = "block";
    div.innerHTML = `<strong>Block #${block.index}</strong><br>
                     <b>Hash:</b> ${block.hash}<br>
                     <b>Previous Hash:</b> ${block.previousHash}<br>
                     <b>Certificates:</b>`;
    block.certificates.forEach(c => {
      const cert = document.createElement("div");
      cert.className = "certificate";
      cert.innerText = `👤 ${c.studentName}, 📘 ${c.course}, 📅 ${c.date}`;
      div.appendChild(cert);
    });
    container.appendChild(div);
  });
}

// Initialize blockchain
blockchain.push(createGenesisBlock());
renderBlockchain();
